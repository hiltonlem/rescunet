# RescuNet
An answer to the 2019 Call for Code Challenge

Video: https://ibm.box.com/s/5giw3q52cp9zwspnoff39brpm4r2ru11

Client            |  Dashboard
:-------------------------:|:-------------------------:
![Client](architecture/rescunet-screenshot.png) | ![Dashboard](architecture/dashboard-screenshot.png)



## Team
| Name | Email|
|:-----|:-----|
| Hilton Lem | hlem@ca.ibm.com |
| Rui Ming Xiong | ruimingxiong@ibm.com |
| Alex Hudici | dhudici@ca.ibm.com |


# Introduction
In a perfect world, rescuers would know the exact location and status of all people in emergency situations. RescuNet is kind of like a digital emergency beacon for your phone. It's an app that helps survivors with no internet access or cell signal be found. 

This document will describe the architecture for delivering a location solution built on top of a wireless mesh network using standard off-the-shelf phones without the need for internet or cellular access.

## Technology
* Wi-Fi Direct
* GPS

## Development Environment
Android Studio
https://developer.android.com/studio

# High Level Architecture

## Client
Using Wifi-Direct, a mobile phone can broadcast its current GPS location to anyone within wifi range. Each phone will also perform peer discovery continuously.
![Peer Discovery](architecture/rescunet-discovery.png)

Each mobile phone will maintain a table of peers that it has discovered and will broadcast its table to each peer. Upon receiving a payload from a peer, it will be merged with its local table. Broadcasting will occur on an interval.
![Broadcast Flow](architecture/peertable.png)

## Dashboard
Once any node in the mesh network gains internet access, the entire location table will be uploaded to the emergency management service in the cloud for plotting on a map. http://rescunetbackend.mybluemix.net/

![Location Upload](architecture/rescunet-upload.jpg)

For the backend source see https://github.ibm.com/rescunet/rescunetbackend

# The Roadmap

Now that there is a running app for Android phones and an emergency dashboard, we have a solution that can be used immediately to help others, but there are some key improvements needed to enable wider adoption:
- A client for Apple devices. The challenge here would be to achieve what was done with Android, but without wifi direct support. As it stands today, Apple devices would be able to see other devices over wifi direct, but would not be able to communicate with them. This could be overcome using the Bonjour service.
- Boost the range. There are examples of drones being controlled over wifi with ranges of 1km.
- Increase accuracy using triangulation.
- Passive mode. Sending pieces of information other than coordinates, such as direct messaging. This feature could use the last three characters of the payload to indicate message type.
- Intelligent broadcasting. Routing tables could use GPS locations to determine next hop and shortest path. devices can intelligently help other devices around them.
- GPS trails. The display would be enhanced to show where you've travelled to avoid going in circles.
- For devices that are known but are out of range, arrows can be shown at the screen edges to indicate presence and their direction. 
- Sending vitals. A client for smartwatches would be able to obtain and send heart rate information to aid in triage. 
- Intelligent dashboard. The dashboard would be enhanced with the Cognos Dashboard Embedded API to provide geographic analysis using their maps.
- Auto identify. Upon gaining internet access, the uploading device could provide identity information.

# References
Wi-Fi Direct Specifications
- https://www.wi-fi.org/discover-wi-fi/wi-fi-direct

Development of Mobile Ad-hoc Networks over Wi-Fi Direct with off-the-shelf phones
- https://ieeexplore.ieee.org/document/7511190

A digital map/GPS based routing and addressing scheme for wireless ad-hoc networks
- https://ieeexplore.ieee.org/document/1212875
